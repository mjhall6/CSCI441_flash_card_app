## Prerequisites for Testing:

* install [jest](https://jestjs.io)
* install dependencies or packages required for the source code

## To run tests:

```bash
npm test
```
