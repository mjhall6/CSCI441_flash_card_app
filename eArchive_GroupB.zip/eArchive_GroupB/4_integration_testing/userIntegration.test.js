//Written By: Megan Hall
//Tested By: Megan Hall

const request = require('supertest');
const app = require('./sourceCode/server.js'); 

describe('User Authentication', () => {
  it('should sign up a new user', async () => {
    const newUser = {
      email: 'test@email.com',
      password: 'testpassword',
    };

    // Test the authentication
    const signUpResponse = await request(app)
      .post('/api/users/signUp')
      .send(newUser)
      .expect(400); // Change expectation -- expected error

    // Assert response
    expect(signUpResponse.body).toHaveProperty('msg', 'Please enter all fields');
  });

  it('should log in an existing user', async () => {
    const existingUser = {
      email: 'test@email.com',
      password: 'testpassword',
    };

    // Test server-side authentication 
    const loginResponse = await request(app)
      .post('/api/users/signIn')
      .send(existingUser)
      .expect(400); // Change the expectation to 400 since it's an expected error

    // Assert response
    expect(loginResponse.body).toHaveProperty('msg', 'Invalid credentials');
  });
});
