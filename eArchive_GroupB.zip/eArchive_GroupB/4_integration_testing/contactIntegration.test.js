//Written by: Megan Hall
//Tested by: Megan Hall

// Import the necessary modules
const { JSDOM } = require('jsdom');

describe('Form Submission Event Listener', () => {
  let dom;
  let form;
  let confirmationMessage;

  beforeEach(() => {
    // Set up a DOM environment
    dom = new JSDOM(`
      <html>
      <body>
        <form id="contactForm">
          <input id="name" type="text" name="name" placeholder="Your Name (required)" required>
          <input id="email" type="email" name="email" placeholder="Your Email (required)" required>
          <textarea id="message" name="message" placeholder="Your Message"></textarea>
          <button type="submit" class="send-message-btn">Send Message</button>
        </form>
        <div id="confirmationMessage" style="display: none;"><strong>Thank you for your message!</strong></div>
      </body>
      </html>
    `);

    // Get references to DOM elements
    form = dom.window.document.getElementById('contactForm');
    confirmationMessage = dom.window.document.getElementById('confirmationMessage');

    // Add the event listener to the form
    dom.window.document.getElementById('contactForm').addEventListener('submit', function(e) {
      // Prevent default form submission behavior
      e.preventDefault();
      
      // Display confirmation message
      confirmationMessage.style.display = 'block';

      // Reset form fields
      form.reset();
    });

    // Spy on the form.reset() method
    jest.spyOn(form, 'reset');
  });

  afterEach(() => {
    // Clean up after each test
    dom.window.close();
  });

  it('should display confirmation message and reset form fields on form submission', () => {
    // Simulate form submission
    form.dispatchEvent(new dom.window.Event('submit'));

    // Expect confirmation message to be displayed
    expect(confirmationMessage.style.display).toBe('block');

    // Expect form fields to be reset
    expect(form.reset).toHaveBeenCalled();
  });
});
