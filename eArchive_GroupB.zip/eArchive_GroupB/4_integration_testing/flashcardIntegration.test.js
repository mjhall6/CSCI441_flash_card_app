//Written By: Megan Hall
//Tested By: Megan Hall

// Mock Flashcard Data
const mockFlashcards = [
    {
      _id: '1',
      category: 'Category 1',
      flashcards: [
        { _id: '1', definition: 'Definition 1', answer: 'Answer 1' },
        { _id: '2', definition: 'Definition 2', answer: 'Answer 2' }
      ]
    },
    {
      _id: '2',
      category: 'Category 2',
      flashcards: [
        { _id: '3', definition: 'Definition 3', answer: 'Answer 3' },
        { _id: '4', definition: 'Definition 4', answer: 'Answer 4' }
      ]
    }
  ];
  
  // Mock Express req/res objects
  const req = {};
  const res = {
    json: jest.fn(),
    status: jest.fn(code => ({ json: jest.fn(data => data) }))
  };
  
  // Importing the controller function
  const flashCardController = require('./sourceCode/controllers/flashCardController.js');
  const _getFlashcards = flashCardController.getFlashcards; // Alias for getFlashcards function

  
  // Test Flashcard Routes
  describe('Flashcard Routes Test', () => {
    // Test for fetching all flashcards
    it('should fetch all flashcards', async () => {
      // Mock getFlashcards behavior 
      const getFlashcards = jest.spyOn(flashCardController, 'getFlashcards');
      // Mock implementation to resolve with mockFlashcards
      getFlashcards.mockResolvedValue(mockFlashcards);
  
      // Call controller function
      await _getFlashcards(req, res);
  
      // Assert the response
      //expect(res.json).toHaveBeenCalled(); // Check if json function is called
      //expect(res.json).toHaveBeenCalledWith(mockFlashcards);
    });
  });
  