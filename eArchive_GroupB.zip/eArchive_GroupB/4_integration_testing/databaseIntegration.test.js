//Written By: Megan Hall
//Tested By: Megan Hall

const request = require('supertest');
const express = require('express');
const mongoose = require('mongoose');
const connectDB = require('./sourceCode/config/dbConn');
const flashcardRoutes = require('./sourceCode/routes/flashcardRoutes');
const userRoutes = require('./sourceCode/routes/userRoutes');
require('dotenv').config({ path: '.env' });

const app = express();

// Set up middleware and routes
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use('/api/flashcards', flashcardRoutes);
app.use('/api/users', userRoutes);

// Define a test endpoint
app.get('/test', (req, res) => {
  res.json({ message: 'Test endpoint works!' });
});

// Connect to MongoDB before running tests
beforeAll(async () => {
  await connectDB();
});

// Close MongoDB connection after tests
afterAll(async () => {
  await mongoose.connection.close();
});

// Integration test for database connection
describe('Database Connection Test', () => {
  it('should connect to the database successfully', async () => {
    expect(mongoose.connection.readyState).toBe(1);
  });
});

// Integration test for server endpoints
describe('Server Test', () => {
  it('should return a message from the test endpoint', async () => {
    const response = await request(app).get('/test');
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('message', 'Test endpoint works!');
  });
});

module.exports = app; // Export the app for testing
