## Prerequisites for Testing:

Install all of the prerequisites from the README file located in the source code file. 
Once the prerequisites are met, you can test the web application using 
An IDE, web browser, and stable internet connection. 

## To run tests:

* Install all packages and dependencies

```bash
npm run dev
```

```bash
node server.js
```

Test application using LiveServer and a web browser with stable internet connection.